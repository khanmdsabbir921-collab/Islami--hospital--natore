ইসলামি হাসপাতাল নাটোর - Android Studio প্রকল্প

এটি APK নয়; APK তৈরির Android Studio source project।

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP Extract করুন।
3. Android Studio > Open দিয়ে IslamiHospitalNatore ফোল্ডার খুলুন।
4. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk ফোল্ডারে পাওয়া যাবে।

গুরুত্বপূর্ণ:
- এটি আগের HTML ডেমোকে Android WebView অ্যাপের মধ্যে চালায়।
- রোগীর তথ্য/সিরিয়াল এখনো অনলাইন সার্ভারে সিঙ্ক হয় না।
- এটি এখনো হাসপাতালের বাস্তব ব্যবহারের জন্য প্রস্তুত নয়।
- অ্যাডমিন পাসওয়ার্ড ও ব্যক্তিগত তথ্য নিরাপদ করতে সার্ভার-ভিত্তিক লগইন ও ডেটাবেস লাগবে।
